from games.chess import chess_loop
from games.space_invaders import space_invaders_loop