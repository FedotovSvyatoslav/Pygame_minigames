CREATE TABLE score (
    value INTEGER
);
