select value
from score;