update score
set value = ?