insert into score (value)
values (null);